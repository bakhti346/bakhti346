package com.example.sajid.readandwrite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class SendDataActivity extends AppCompatActivity {
    private static String SOAP_ACTION1 = "http://demoservice.android.com/WriteData";
    private static String NAMESPACE = "http://demoservice.android.com/";
    private static String METHOD_NAME1 = "WriteData";
    private static String URL = "http://sajid-pc:31141/demoAndroidwebService.asmx?WSDL";
    Button dataWrite;
    EditText text_ID, text_Name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_data);
        dataWrite = (Button) findViewById(R.id.write_button);
        text_ID = (EditText) findViewById(R.id.write_Id);
        text_Name = (EditText) findViewById(R.id.write_Name);
        dataWrite.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("WriteData", text_ID.getText().toString());
                request.addProperty("WriteData",text_Name.getText().toString());
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    androidHttpTransport.call(SOAP_ACTION1, envelope);
                    SoapObject result = (SoapObject) envelope.bodyIn;
                    //Toast.makeText( "Data sent successfully",Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
